# Semana 2: Plaza central y ambientación

**Objetivo:** Construir el parque central: plaza circular con templete, 8 entradas, césped con árboles y marcadores de parada.

## Qué hay de nuevo

- Plaza circular elevada (35 cm) en el centro del parque y anillo pavimentado a su alrededor
- 8 entradas: 4 senderos rectos (N, E, S, O) y 4 diagonales que llegan a las esquinas, cada uno con dos escalones hacia la plaza
- 16 pilares blancos (2 por entrada) y 4 plazoletas de esquina
- Templete blanco circular: 3 gradas, 12 columnas con capitel, cornisa, ático con pilastras y paneles, y 12 urnas en lo alto
- 8 zonas de césped, cada una con un árbol, y 8 faroles junto a la plaza
- Marcadores de parada: restaurante (naranja), clientes A–E (amarillo) y base (azul)

## Actividades de la semana

- [ ] Comparar el parque con una foto aérea de un parque real: plaza central, senderos y césped.
- [ ] Contar las 8 entradas (N, NE, E, SE, S, SO, O, NO) y reconocer sus pilares.
- [ ] Medir el ancho de la calle anillo (3 m) y comprobar que el robot (0.5 x 0.3 m) circula con holgura.
- [ ] Cambiar el ancho de los senderos o el radio de la plaza en `parque()` y regenerar el mundo.
- [ ] Ubicar los marcadores (`MARCADORES`) y explicar por qué cada uno queda frente a una casa.
- [ ] Modificar el templete en `tools/templete.py` (número de columnas, altura, radio), regenerar con `python3 tools/construir_proyecto.py` y comparar con una foto real del templete.
- [ ] Generar la vista previa con `python3 tools/vista_previa_templete.py` y revisar las proporciones.

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Esta semana todavía no hay robot: solo se explora el mundo.

## Entregable

Mundo con el parque personalizado y una tabla con el ancho libre de la calle anillo.

## Criterios de evaluación

- El parque tiene 8 entradas y la plaza está en el centro
- El ancho de la calle permite circular al robot
- Los marcadores están en el lugar correcto

## Siguiente

Semana 3: el robot diferencial y su primer movimiento.

---
Carpeta: `semana_02`. Proyecto principal: [`../README.md`](../README.md)
