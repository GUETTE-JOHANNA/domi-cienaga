# Semana 1: Entorno y mundo base

**Objetivo:** Instalar y configurar Webots, entender cómo se organiza un proyecto y construir el mundo base del barrio: terreno, calle anillo, casas y el lote del parque.

## Qué hay de nuevo

- Terreno de 24 x 24 m con paredes bajas
- Lote cuadrado de 12 x 12 m en el centro, donde irá el parque con la plaza y sus 8 entradas
- Calle anillo de 3 m de ancho alrededor del parque (por ahí circulará el robot)
- 16 casas coloniales de colores fuera del anillo (una es el restaurante, en naranja, y otra la base, en azul)

## Actividades de la semana

- [ ] Instalar Webots R2023b o superior y configurar el comando de Python (Tools → Preferences).
- [ ] Abrir `worlds/cienaga.wbt` y moverse por el mundo con el ratón (rotar, zoom, desplazar).
- [ ] Entender los ejes ENU: x = este, y = norte, z = arriba; todo está en metros.
- [ ] Leer `tools/generar_mundo.py` e identificar las funciones `calle()`, `casa()` y `parque()`.
- [ ] Cambiar colores y alturas de las casas, regenerar el mundo y volver a abrirlo.
- [ ] Dibujar un croquis del sector real de Ciénaga que se quiere representar (calles, parque, puntos de referencia).

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Esta semana todavía no hay robot: solo se explora el mundo.

## Entregable

Mundo abierto en Webots (captura de pantalla) y croquis del sector.

## Criterios de evaluación

- Webots abre el mundo sin errores
- Se explican los ejes y las unidades
- El croquis identifica calles y puntos de referencia

## Siguiente

Semana 2: plaza, templete, senderos y las 8 entradas del parque.

---
Carpeta: `semana_01`. Proyecto principal: [`../README.md`](../README.md)
