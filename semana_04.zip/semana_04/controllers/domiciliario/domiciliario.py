"""Semana 4 - Sensores: telemetría con GPS, rumbo y sensores de distancia.

El robot avanza despacio hacia el este y se detiene cuando el sensor central
detecta una pared (el muro de la arena) a menos de 0.5 m. Cada segundo imprime su posición,
su rumbo y las 5 distancias medidas.
"""
import math
from controller import Supervisor

WHEEL_RADIUS = 0.08
HALF_TRACK = 0.19
V = 0.4
DIST_PARADA = 0.5   # m


def main():
    robot = Supervisor()
    ts = int(robot.getBasicTimeStep())
    yo = robot.getSelf()
    izq = robot.getDevice("left wheel motor")
    der = robot.getDevice("right wheel motor")
    for m in (izq, der):
        m.setPosition(float("inf"))
        m.setVelocity(V / WHEEL_RADIUS)

    gps = robot.getDevice("gps")
    gps.enable(ts)
    nombres = ["ds_left", "ds_center", "ds_right", "ds_left_side", "ds_right_side"]
    sensores = {n: robot.getDevice(n) for n in nombres}
    for s in sensores.values():
        s.enable(ts)

    proximo_print = 0.0
    parado = False
    while robot.step(ts) != -1:
        t = robot.getTime()
        # El sensor entrega mm: valor/1000 = metros (1.5 m = nada a la vista)
        dist = {n: s.getValue() / 1000.0 for n, s in sensores.items()}

        if not parado and dist["ds_center"] < DIST_PARADA:
            izq.setVelocity(0.0)
            der.setVelocity(0.0)
            parado = True
            print("[semana 4] Obstáculo al frente: robot detenido")

        if t >= proximo_print:
            x, y, _ = gps.getValues()
            R = yo.getOrientation()
            yaw = math.degrees(math.atan2(R[3], R[0]))
            texto = " ".join(f"{n[3:]}={d:.2f}" for n, d in dist.items())
            print(f"[semana 4] t={t:5.1f}s pos=({x:5.2f},{y:5.2f}) rumbo={yaw:6.1f}° {texto}")
            proximo_print = t + 1.0


if __name__ == "__main__":
    main()
