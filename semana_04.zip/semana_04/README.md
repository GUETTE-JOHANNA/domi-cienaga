# Semana 4: Sensores: GPS, rumbo y distancia

**Objetivo:** Dotar al robot de percepción: posición (GPS), rumbo y cinco sensores de distancia.

## Qué hay de nuevo

- GPS y 5 sensores de distancia (izquierdo, central, derecho y dos laterales)
- Controlador `ctrl_s04_sensores.py`: telemetría cada segundo y parada ante una pared

## Actividades de la semana

- [ ] Entender la salida del sensor: `lookupTable [0 0 0, 1.5 1500 0]` → valor = distancia en mm.
- [ ] Leer posición con `gps.getValues()` y rumbo con la orientación del robot.
- [ ] Ejecutar el controlador y comprobar que se detiene a ~0.5 m de la casa.
- [ ] Hacer una tabla distancia real vs. distancia medida con 3 puntos distintos.
- [ ] Probar qué ve cada sensor al acercarse en diagonal a una pared.

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Pulsa ▶ (Run). El robot arranca solo.

## Entregable

Registro de telemetría (copia de la consola) y la tabla de comparación de distancias.

## Criterios de evaluación

- Se leen GPS, rumbo y distancias
- El robot se detiene ante la pared
- La tabla muestra el error de medición

## Siguiente

Semana 5: control proporcional para ir a un punto.

---
Carpeta: `semana_04`. Proyecto principal: [`../README.md`](../README.md)
