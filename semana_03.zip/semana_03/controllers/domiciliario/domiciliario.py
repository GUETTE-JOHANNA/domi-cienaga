"""Semana 3 - Movimiento en lazo abierto: el robot dibuja un cuadrado en la calle norte (junto al parque).

Sólo usa los dos motores de las ruedas. Avanza durante un tiempo fijo y gira
durante un tiempo fijo. Como no hay sensores, el cuadrado nunca cierra
exactamente: ese error es el motivo de añadir GPS y rumbo en la semana 4.
"""
import math
from controller import Supervisor

WHEEL_RADIUS = 0.08
HALF_TRACK = 0.19

V_AVANCE = 0.6           # m/s
T_AVANCE = 3.0           # s  -> lado de ~1.8 m
W_GIRO = 1.0             # rad/s (giro a la derecha, en sentido horario)
T_GIRO = (math.pi / 2) / W_GIRO   # s para ~90 grados
LADOS = 4


def main():
    robot = Supervisor()
    ts = int(robot.getBasicTimeStep())
    izq = robot.getDevice("left wheel motor")
    der = robot.getDevice("right wheel motor")
    for m in (izq, der):
        m.setPosition(float("inf"))
        m.setVelocity(0.0)

    def mover(v, w):
        izq.setVelocity((v - w * HALF_TRACK) / WHEEL_RADIUS)
        der.setVelocity((v + w * HALF_TRACK) / WHEEL_RADIUS)

    # Plan: (v, w, duración)
    plan = []
    for _ in range(LADOS):
        plan.append((V_AVANCE, 0.0, T_AVANCE))
        plan.append((0.0, -W_GIRO, T_GIRO))
    plan.append((0.0, 0.0, 1e9))   # parar al final

    i, t_inicio = 0, robot.getTime()
    mover(*plan[0][:2])
    while robot.step(ts) != -1:
        if robot.getTime() - t_inicio >= plan[i][2]:
            i += 1
            t_inicio = robot.getTime()
            mover(*plan[i][:2])
            print("[semana 3] paso", i + 1, "de", len(plan))


if __name__ == "__main__":
    main()
