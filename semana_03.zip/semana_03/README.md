# Semana 3: Robot diferencial y movimiento

**Objetivo:** Construir el robot (chasis, dos ruedas motrices y dos ruedas locas) y moverlo en lazo abierto.

## Qué hay de nuevo

- Robot con chasis rojo, caja de reparto amarilla, 2 ruedas con motor y 2 ruedas locas
- Controlador `ctrl_s03_movimiento.py`: dibuja un cuadrado por tiempo

## Actividades de la semana

- [ ] Identificar en el mundo el nodo `Robot`: `HingeJoint` + `RotationalMotor` por rueda.
- [ ] Entender la cinemática diferencial: `v_izq = (v - w·b)/r` y `v_der = (v + w·b)/r` (b = 0.19 m, r = 0.08 m).
- [ ] Ejecutar el cuadrado y medir con qué error vuelve al punto de inicio.
- [ ] Cambiar `V_AVANCE`, `T_AVANCE` y `W_GIRO` y observar cómo cambia el error.
- [ ] Explicar por qué el lazo abierto no sirve para repartir: hace falta saber dónde está el robot.

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Pulsa ▶ (Run). El robot arranca solo.

> Si las ruedas se ven acostadas, cambia `WHEEL_ROT` en `tools/generar_mundo.py` y regenera el mundo (ver README principal).

## Entregable

Video o capturas del cuadrado y una nota con el error medido.

## Criterios de evaluación

- El robot se mueve y gira
- Se explica la fórmula de la cinemática diferencial
- Se cuantifica el error de lazo abierto

## Siguiente

Semana 4: sensores para conocer posición, rumbo y obstáculos.

---
Carpeta: `semana_03`. Proyecto principal: [`../README.md`](../README.md)
