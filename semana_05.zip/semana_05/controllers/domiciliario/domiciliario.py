"""Semana 5 - Control de movimiento: ir a un punto con control proporcional.

El robot recorre una lista de puntos en la calle norte, junto al parque. En cada paso calcula:
  - la distancia al objetivo (para decidir cuándo llegó),
  - el error de rumbo (ángulo hacia el objetivo - rumbo actual),
y ajusta la velocidad de las ruedas con una ganancia proporcional (KP).
"""
import math
from controller import Supervisor

WHEEL_RADIUS = 0.08
HALF_TRACK = 0.19
V_MAX = 0.8
KP = 2.2
OMEGA_MAX = 2.2
TOLERANCIA = 0.15      # m
PUNTOS = [(2.0, 8.5), (2.0, 6.8), (-2.0, 6.8), (-2.0, 8.5), (0.0, 8.5)]


def normalizar(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a


def main():
    robot = Supervisor()
    ts = int(robot.getBasicTimeStep())
    yo = robot.getSelf()
    izq = robot.getDevice("left wheel motor")
    der = robot.getDevice("right wheel motor")
    for m in (izq, der):
        m.setPosition(float("inf"))
        m.setVelocity(0.0)
    gps = robot.getDevice("gps")
    gps.enable(ts)

    def mover(v, w):
        izq.setVelocity(max(-13, min(13, (v - w * HALF_TRACK) / WHEEL_RADIUS)))
        der.setVelocity(max(-13, min(13, (v + w * HALF_TRACK) / WHEEL_RADIUS)))

    i = 0
    while robot.step(ts) != -1:
        if i >= len(PUNTOS):
            mover(0, 0)
            continue
        x, y, _ = gps.getValues()
        R = yo.getOrientation()
        yaw = math.atan2(R[3], R[0])
        dx, dy = PUNTOS[i][0] - x, PUNTOS[i][1] - y
        dist = math.hypot(dx, dy)
        if dist < TOLERANCIA:
            print(f"[semana 5] llegó al punto {i + 1}: {PUNTOS[i]}")
            i += 1
            continue
        err = normalizar(math.atan2(dy, dx) - yaw)
        w = max(-OMEGA_MAX, min(OMEGA_MAX, KP * err))
        v = 0.0 if abs(err) > 1.0 else V_MAX * math.cos(err) * min(1.0, dist)
        mover(max(v, 0.0), w)


if __name__ == "__main__":
    main()
