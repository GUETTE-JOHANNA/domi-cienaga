# Semana 5: Control: ir a un punto

**Objetivo:** Navegar de forma cerrada hacia un punto usando la posición y el rumbo (control proporcional).

## Qué hay de nuevo

- Controlador `ctrl_s05_ir_a_punto.py`: recorre 5 puntos en la calle norte, junto al parque

## Actividades de la semana

- [ ] Calcular distancia y error de rumbo al objetivo en cada paso de simulación.
- [ ] Girar en el sitio cuando el error es grande y avanzar cuando está alineado.
- [ ] Variar `KP` (por ejemplo 0.5, 2.2 y 6) y describir el comportamiento: lento, bueno u oscilante.
- [ ] Ajustar `TOLERANCIA` y ver qué pasa si es demasiado pequeña.
- [ ] Explicar por qué se reduce la velocidad al acercarse a un punto.

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Pulsa ▶ (Run). El robot arranca solo.

## Entregable

Gráfica o descripción del recorrido con 3 valores de `KP` y la elección justificada.

## Criterios de evaluación

- Llega a los 5 puntos
- Se justifica el valor de KP
- No hay oscilaciones al llegar

## Siguiente

Semana 6: ruta completa rodeando el parque.

---
Carpeta: `semana_05`. Proyecto principal: [`../README.md`](../README.md)
