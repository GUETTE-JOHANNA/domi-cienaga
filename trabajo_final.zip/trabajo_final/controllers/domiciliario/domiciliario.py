"""Controlador del robot domiciliario - Ciénaga, Magdalena (Webots, Python).

Este archivo se usa de la semana 6 a la 12. La constante FASE indica la semana:
  6  Ruta fija con waypoints rodeando el parque (sin evasión, sin paquete)
  7  + Evasión de obstáculos con sensores de distancia
  8  + Máquina de estados de entrega con paquete y marcadores (Supervisor)
  9  + Detección de atascos, recuperación y HUD en pantalla
  10 + Grafo de calles, planificación con Dijkstra y pedidos.json
  11 + Métricas en metricas.csv
  12 + Repetición de ruta y resumen final (versión del trabajo final)

Dispositivos (definidos en worlds/cienaga.wbt):
  "left wheel motor", "right wheel motor", "gps",
  "ds_left", "ds_center", "ds_right", "ds_left_side", "ds_right_side".
El rumbo (yaw) se obtiene con la orientación del nodo (API de Supervisor).
"""
import heapq
import json
import math
import os
from controller import Supervisor

FASE = 12

# ----------------------------------------------------------------- Parámetros
WHEEL_RADIUS = 0.08        # m
HALF_TRACK = 0.19          # m (mitad de la distancia entre ruedas)
MAX_WHEEL_SPEED = 13.0     # rad/s (< maxVelocity del motor)
V_MAX = 0.9                # m/s velocidad de crucero
KP_HEADING = 2.2           # ganancia de giro hacia el objetivo
OMEGA_MAX = 2.2            # rad/s giro máximo por navegación
SAFE_DIST = 0.7            # m, distancia frontal a la que empieza la evasión
SIDE_SAFE = 0.45           # m, distancia lateral mínima deseada
AVOID_GAIN = 3.0           # rad/s por unidad de peligro
TOL_VIA = 0.45             # m, tolerancia en puntos de paso
TOL_STOP = 0.20            # m, tolerancia en puntos de parada
WAIT_TIME = 2.0            # s detenido al recoger / entregar

COLOR_PENDIENTE = [1.0, 0.9, 0.0]
COLOR_HECHO = [0.1, 0.8, 0.2]

DIR = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------ Mapa (grafo)
# Calle anillo de 3 m alrededor del parque central; el robot circula por el carril
# exterior (a 8.5 m del centro) y las paradas están sobre ese carril.
NODOS = {
    "NO": (-8.5, 8.5), "VREST": (-4.8, 8.5), "N0": (0.0, 8.5), "VCA": (4.8, 8.5),
    "NE": (8.5, 8.5), "VCB": (8.5, 4.8), "EE": (8.5, 0.0), "VCC": (8.5, -4.8),
    "SE": (8.5, -8.5), "VCD": (4.8, -8.5), "SS": (0.0, -8.5), "SSO": (-4.8, -8.5),
    "SO": (-8.5, -8.5), "OS": (-8.5, -4.8), "VCE": (-8.5, 0.0), "ON": (-8.5, 4.8),
    # paradas: misma posición que su punto de paso en el carril, así el planificador
    # solo se detiene en las paradas que forman parte del pedido
    "REST": (-4.8, 8.5), "BASE": (0.0, 8.5), "CA": (4.8, 8.5), "CB": (8.5, 4.8),
    "CC": (8.5, -4.8), "CD": (4.8, -8.5), "CE": (-8.5, 0.0),
}
ARISTAS = [
    ("NO", "VREST"), ("VREST", "N0"), ("N0", "VCA"), ("VCA", "NE"),
    ("NE", "VCB"), ("VCB", "EE"), ("EE", "VCC"), ("VCC", "SE"),
    ("SE", "VCD"), ("VCD", "SS"), ("SS", "SSO"), ("SSO", "SO"),
    ("SO", "OS"), ("OS", "VCE"), ("VCE", "ON"), ("ON", "NO"),
    ("VREST", "REST"), ("N0", "BASE"), ("VCA", "CA"), ("VCB", "CB"),
    ("VCC", "CC"), ("VCD", "CD"), ("VCE", "CE"),
]
NOMBRES = {
    "BASE": "Base", "REST": "Restaurante El Muelle",
    "CA": "Cliente A (Familia Pérez)", "CB": "Cliente B (Tienda La Esquina)",
    "CC": "Cliente C (Don Luis)", "CD": "Cliente D (Doña Rosa)", "CE": "Cliente E (Panadería)",
}
TIPOS = {"REST": "pickup", "CA": "drop", "CB": "drop", "CC": "drop", "CD": "drop",
         "CE": "drop", "BASE": "home"}
MARCAS = {"REST": "R", "CA": "A", "CB": "B", "CC": "C", "CD": "D", "CE": "E", "BASE": "BASE"}
CLIENTES = {"A": "CA", "B": "CB", "C": "CC", "D": "CD", "E": "CE"}
PEDIDOS_POR_DEFECTO = ["E", "D", "C", "B", "A"]   # los 5 clientes marcados

# Ruta fija (semanas 6 a 9): restaurante -> E -> D -> C -> B -> A -> base,
# dando la vuelta al parque en sentido antihorario
RUTA_FIJA_NODOS = [
    "REST", "NO", "ON", "CE", "OS", "SO", "SSO", "SS", "CD", "SE",
    "CC", "EE", "CB", "NE", "CA", "BASE",
]


def _peso(a, b):
    (x1, y1), (x2, y2) = NODOS[a], NODOS[b]
    return math.hypot(x2 - x1, y2 - y1)


def _vecinos():
    v = {n: [] for n in NODOS}
    for a, b in ARISTAS:
        p = _peso(a, b)
        v[a].append((b, p))
        v[b].append((a, p))
    return v


def camino(origen, destino):
    """Camino más corto entre dos nodos del mapa (Dijkstra)."""
    vecinos = _vecinos()
    dist = {origen: 0.0}
    previo = {}
    cola = [(0.0, origen)]
    while cola:
        d, n = heapq.heappop(cola)
        if n == destino:
            break
        if d > dist.get(n, float("inf")):
            continue
        for m, p in vecinos[n]:
            nd = d + p
            if nd < dist.get(m, float("inf")):
                dist[m] = nd
                previo[m] = n
                heapq.heappush(cola, (nd, m))
    ruta = [destino]
    while ruta[-1] != origen:
        ruta.append(previo[ruta[-1]])
    return ruta[::-1]


def construir_ruta(nodos):
    """Convierte una lista de nodos en pasos (nombre, (x, y), tipo, marca)."""
    return [(NOMBRES.get(n, "Vía"), NODOS[n], TIPOS.get(n, "via"), MARCAS.get(n))
            for n in nodos]


def planificar(pedidos):
    """Base -> restaurante (recoge todo el lote) -> clientes en orden -> base."""
    nodos, actual = [], "BASE"
    for destino in ["REST"] + [CLIENTES[c] for c in pedidos] + ["BASE"]:
        nodos += camino(actual, destino)[1:]
        actual = destino
    return construir_ruta(nodos)


def cargar_config():
    """Lee pedidos.json (semana 10+). Devuelve (pedidos, repetir)."""
    pedidos, repetir = list(PEDIDOS_POR_DEFECTO), False
    try:
        with open(os.path.join(DIR, "pedidos.json"), encoding="utf-8") as f:
            cfg = json.load(f)
        validos = [c for c in cfg.get("pedidos", []) if c in CLIENTES]
        if validos:
            pedidos = validos
        repetir = bool(cfg.get("repetir", False))
    except (OSError, ValueError):
        pass
    return pedidos, repetir


# ---------------------------------------------------------------- Utilidades
def normalizar(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a


def limitar(v, lo, hi):
    return max(lo, min(hi, v))


class Metricas:
    """Registro de eventos en metricas.csv (semana 11+)."""

    def __init__(self):
        self.ruta = os.path.join(DIR, "metricas.csv")
        self.atascos = 0
        try:
            with open(self.ruta, "w", encoding="utf-8") as f:
                f.write("tiempo_s,evento,x,y,entregas,distancia_m,detalle\n")
        except OSError:
            self.ruta = None

    def evento(self, t, evento, x, y, entregas, distancia, detalle=""):
        if not self.ruta:
            return
        try:
            with open(self.ruta, "a", encoding="utf-8") as f:
                f.write(f"{t:.2f},{evento},{x:.2f},{y:.2f},{entregas},{distancia:.2f},{detalle}\n")
        except OSError:
            pass


class Domiciliario:
    def __init__(self):
        self.robot = Supervisor()
        self.ts = int(self.robot.getBasicTimeStep())
        self.me = self.robot.getSelf()

        self.motor_i = self.robot.getDevice("left wheel motor")
        self.motor_d = self.robot.getDevice("right wheel motor")
        for m in (self.motor_i, self.motor_d):
            m.setPosition(float("inf"))
            m.setVelocity(0.0)

        self.ds_i = self.robot.getDevice("ds_left")
        self.ds_c = self.robot.getDevice("ds_center")
        self.ds_d = self.robot.getDevice("ds_right")
        self.ds_li = self.robot.getDevice("ds_left_side")
        self.ds_ld = self.robot.getDevice("ds_right_side")
        for s in (self.ds_i, self.ds_c, self.ds_d, self.ds_li, self.ds_ld):
            s.enable(self.ts)
        self.gps = self.robot.getDevice("gps")
        self.gps.enable(self.ts)

        # Elementos visuales (opcionales: si no existen en el mundo, se ignoran)
        self.paquete = self._campo("PKG_APP", "transparency") if FASE >= 8 else None
        self.marcas = {}
        if FASE >= 8:
            for clave in ("R", "A", "B", "C", "D", "E", "BASE"):
                self.marcas[clave] = self._campo("MARK_" + clave, "baseColor")

        # Ruta
        self.repetir = False
        if FASE >= 10:
            self.pedidos, rep = cargar_config()
            self.ruta = planificar(self.pedidos)
            self.repetir = rep if FASE >= 12 else False
        else:
            self.ruta = construir_ruta(RUTA_FIJA_NODOS)
        self.total_entregas = sum(1 for p in self.ruta if p[2] == "drop")

        self.idx = 0
        self.estado = "MOVING"   # MOVING | WAITING | RECOVER | DONE
        self.t_fin = 0.0
        self.entregas = 0
        self.chk_t = 0.0
        self.chk_pos = None
        self.metricas = Metricas() if FASE >= 11 else None
        self.dist_total = 0.0
        self.ult_pos = None
        self.t_ini = 0.0

    # ------------------------------------------------------------ utilidades
    def _campo(self, def_name, campo):
        nodo = self.robot.getFromDef(def_name)
        return nodo.getField(campo) if nodo else None

    def _hud(self, texto):
        if FASE >= 9:
            self.robot.setLabel(0, texto, 0.02, 0.02, 0.07, 0xFFFFFF, 0.0, "Arial")
        print("[domiciliario]", texto)

    def _registrar(self, evento, detalle=""):
        if self.metricas:
            x, y = self._pos()
            self.metricas.evento(self.robot.getTime(), evento, x, y,
                                 self.entregas, self.dist_total, detalle)

    def _pos(self):
        p = self.gps.getValues()
        return p[0], p[1]

    def _yaw(self):
        R = self.me.getOrientation()   # 3x3 por filas; columna 0 = eje x del robot
        return math.atan2(R[3], R[0])

    def _mover(self, v, w):
        """v: m/s hacia delante, w: rad/s antihorario."""
        vi = (v - w * HALF_TRACK) / WHEEL_RADIUS
        vd = (v + w * HALF_TRACK) / WHEEL_RADIUS
        self.motor_i.setVelocity(limitar(vi, -MAX_WHEEL_SPEED, MAX_WHEEL_SPEED))
        self.motor_d.setVelocity(limitar(vd, -MAX_WHEEL_SPEED, MAX_WHEEL_SPEED))

    def _mostrar_paquete(self, visible):
        if self.paquete:
            self.paquete.setSFFloat(0.0 if visible else 1.0)

    def _pintar_marca(self, clave, color):
        campo = self.marcas.get(clave)
        if campo:
            campo.setSFColor(color)

    # ------------------------------------------------------------- navegación
    def _comando(self, x, y, yaw, objetivo, tipo):
        dx, dy = objetivo[0] - x, objetivo[1] - y
        dist = math.hypot(dx, dy)
        err = normalizar(math.atan2(dy, dx) - yaw)

        p_max, w_av = 0.0, 0.0
        if FASE >= 7:   # evasión de obstáculos
            di = self.ds_i.getValue() / 1000.0
            dc = self.ds_c.getValue() / 1000.0
            dd = self.ds_d.getValue() / 1000.0
            pel = [max(0.0, (SAFE_DIST - d) / SAFE_DIST) for d in (di, dc, dd)]
            sl = max(0.0, (SIDE_SAFE - self.ds_li.getValue() / 1000.0) / SIDE_SAFE)
            sr = max(0.0, (SIDE_SAFE - self.ds_ld.getValue() / 1000.0) / SIDE_SAFE)
            p_max = max(pel)
            # obstáculo a la derecha -> girar a la izquierda (w > 0)
            w_av = AVOID_GAIN * (pel[2] - pel[0]) + 2.0 * AVOID_GAIN * (sr - sl)
            if pel[1] > 0.2 and abs(pel[0] - pel[2]) < 0.1:
                w_av += 1.5 * pel[1]      # de frente: rompe la simetría girando a la izquierda

        w_nav = limitar(KP_HEADING * err, -OMEGA_MAX, OMEGA_MAX) * (1.0 - 0.7 * p_max)
        w = w_nav + w_av

        if abs(err) > 1.0:
            v = 0.0                        # girar en el sitio si está muy desalineado
        else:
            v = V_MAX * math.cos(err)
        v *= (1.0 - 0.85 * p_max)
        if tipo != "via":
            v *= limitar(dist, 0.3, 1.0)   # frenar al acercarse a una parada
        return v, w, dist

    # ----------------------------------------------------------------- acciones
    def _al_llegar(self, ahora):
        nombre, _, tipo, marca = self.ruta[self.idx]
        if tipo == "via":
            self.idx += 1
        elif tipo in ("pickup", "drop"):
            self.estado = "WAITING"
            self.t_fin = ahora + WAIT_TIME
            self._mover(0, 0)
            accion = "Recogiendo pedido en" if tipo == "pickup" else "Entregando en"
            self._hud(f"{accion} {nombre}")
            self._registrar("llegada_" + tipo, nombre)
        elif tipo == "home":
            self._mover(0, 0)
            self._pintar_marca("BASE", COLOR_HECHO)
            self._hud(f"Ruta completada: {self.entregas}/{self.total_entregas} entregas")
            self._registrar("fin", "ruta completada")
            if FASE >= 12:
                self._resumen(ahora)
            if self.repetir:
                self._reiniciar()
            else:
                self.estado = "DONE"

    def _terminar_espera(self):
        nombre, _, tipo, marca = self.ruta[self.idx]
        if tipo == "pickup":
            self._mostrar_paquete(True)
        else:
            self.entregas += 1
            # el paquete se ve hasta entregar el último pedido
            self._mostrar_paquete(self.entregas < self.total_entregas)
        self._pintar_marca(marca, COLOR_HECHO)
        self._registrar("completado_" + tipo, nombre)
        self.idx += 1
        self.estado = "MOVING"
        sig = self.ruta[self.idx][0] if self.idx < len(self.ruta) else "-"
        self._hud(f"Entregas {self.entregas}/{self.total_entregas}. Siguiente: {sig}")

    def _reiniciar(self):
        self.idx = 0
        self.entregas = 0
        self.estado = "MOVING"
        self.t_ini = self.robot.getTime()
        self.dist_total = 0.0
        for clave in ("R", "A", "B", "C", "D", "E"):
            self._pintar_marca(clave, COLOR_PENDIENTE)
        self._pintar_marca("BASE", [0.2, 0.4, 1.0])

    def _resumen(self, ahora):
        dur = max(ahora - self.t_ini, 1e-6)
        print("[domiciliario] RESUMEN: %d/%d entregas, %.1f s, %.1f m, %.2f m/s medios"
              % (self.entregas, self.total_entregas, dur, self.dist_total,
                 self.dist_total / dur))

    # -------------------------------------------------------------------- bucle
    def run(self):
        self._mostrar_paquete(False)
        self._hud("Iniciando ruta de domicilios en Ciénaga")
        self._registrar("inicio")
        while self.robot.step(self.ts) != -1:
            ahora = self.robot.getTime()
            x, y = self._pos()
            yaw = self._yaw()

            if FASE >= 11:   # distancia recorrida
                if self.ult_pos is not None:
                    self.dist_total += math.hypot(x - self.ult_pos[0], y - self.ult_pos[1])
                self.ult_pos = (x, y)

            if self.estado == "DONE":
                self._mover(0, 0)
                continue

            if self.estado == "WAITING":
                self._mover(0, 0)
                if ahora >= self.t_fin:
                    self._terminar_espera()
                continue

            if self.estado == "RECOVER":
                self._mover(-0.3, 1.0)
                if ahora >= self.t_fin:
                    self.estado = "MOVING"
                    self.chk_pos, self.chk_t = (x, y), ahora
                continue

            # --- MOVING ---
            if FASE >= 9:   # detección de atasco: casi sin avance en 4 s
                if self.chk_pos is None:
                    self.chk_pos, self.chk_t = (x, y), ahora
                elif ahora - self.chk_t > 4.0:
                    if math.hypot(x - self.chk_pos[0], y - self.chk_pos[1]) < 0.08:
                        self.estado = "RECOVER"
                        self.t_fin = ahora + 1.5
                        self._hud("Atascado: maniobra de recuperación")
                        self._registrar("atasco")
                        continue
                    self.chk_pos, self.chk_t = (x, y), ahora

            nombre, objetivo, tipo, _ = self.ruta[self.idx]
            v, w, dist = self._comando(x, y, yaw, objetivo, tipo)
            tol = TOL_VIA if tipo == "via" else TOL_STOP
            if dist < tol:
                self._al_llegar(ahora)
            else:
                self._mover(v, w)


if __name__ == "__main__":
    Domiciliario().run()
