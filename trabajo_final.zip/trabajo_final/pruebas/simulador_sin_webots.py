"""Simulador cinemático mínimo para probar el controlador SIN Webots.

Uso:
    python3 simulador_sin_webots.py <carpeta_del_controlador> [--semana N] [--segundos S]

Ejemplo (desde la carpeta del trabajo final):
    python3 pruebas/simulador_sin_webots.py controllers/domiciliario --semana 12

Reproduce el mapa (casas, parque, bolardos, moto), los sensores de
distancia, el GPS y la cinemática diferencial. No reemplaza a Webots (no hay
física real), pero sirve para validar rápido la lógica de rutas, evasión y
entregas, y detecta choques contra los obstáculos del mapa.
"""
import argparse
import math
import os
import sys
import types

# ----------------------------------------------------------------- Mapa
# (nombre, cx, cy, sx, sy, rotación)
def construir_obstaculos(semana):
    obs = []
    # 16 casas fuera del anillo (mismas posiciones que tools/generar_mundo.py)
    for i, x in enumerate((-9.6, -4.8, 0.0, 4.8, 9.6)):
        obs.append((f"casa_n{i + 1}", x, 10.6, 3.6, 2.4, 0.0))
        obs.append((f"casa_s{i + 1}", x, -10.6, 3.6, 2.4, 0.0))
    for i, y in enumerate((4.8, 0.0, -4.8)):
        obs.append((f"casa_e{i + 1}", 10.6, y, 2.4, 3.6, 0.0))
        obs.append((f"casa_o{i + 1}", -10.6, y, 2.4, 3.6, 0.0))
    obs.append(("parque", 0, 0, 12.0, 12.0, 0.0))   # bordillo del parque (no se entra)
    if semana >= 7:
        obs.append(("bolardo_1", -2.4, -8.0, 0.3, 0.3, 0.0))
        obs.append(("bolardo_2", 8.0, 2.4, 0.3, 0.3, 0.0))
        obs.append(("moto_estacionada", -2.8, 8.0, 1.0, 0.4, 0.0))
    obs += [("muro_n", 0, 12, 24, 0.1, 0.0), ("muro_s", 0, -12, 24, 0.1, 0.0),
            ("muro_e", 12, 0, 0.1, 24, 0.0), ("muro_o", -12, 0, 0.1, 24, 0.0)]
    return obs


def a_local(px, py, caja):
    _, cx, cy, _, _, rot = caja
    c, s = math.cos(-rot), math.sin(-rot)
    lx, ly = px - cx, py - cy
    return lx * c - ly * s, lx * s + ly * c


def rayo_caja(ox, oy, ang, caja, maxd=1.5):
    _, _, _, sx, sy, rot = caja
    lx, ly = a_local(ox, oy, caja)
    dx, dy = math.cos(ang - rot), math.sin(ang - rot)
    tmin, tmax = 0.0, maxd
    for o, d, mitad in ((lx, dx, sx / 2), (ly, dy, sy / 2)):
        if abs(d) < 1e-9:
            if o < -mitad or o > mitad:
                return maxd
        else:
            t1, t2 = (-mitad - o) / d, (mitad - o) / d
            if t1 > t2:
                t1, t2 = t2, t1
            tmin, tmax = max(tmin, t1), min(tmax, t2)
            if tmin > tmax:
                return maxd
    return min(tmin, maxd)


# ------------------------------------------------------- Dispositivos falsos
class Motor:
    def __init__(self):
        self.v = 0.0

    def setPosition(self, p):
        pass

    def setVelocity(self, v):
        self.v = max(-14.0, min(14.0, v))


class Sensor:
    def __init__(self, sim, dx, dy, ang):
        self.sim, self.o = sim, (dx, dy, ang)

    def enable(self, t):
        pass

    def getValue(self):
        s = self.sim
        dx, dy, a = self.o
        ox = s.x + dx * math.cos(s.yaw) - dy * math.sin(s.yaw)
        oy = s.y + dx * math.sin(s.yaw) + dy * math.cos(s.yaw)
        return min(rayo_caja(ox, oy, s.yaw + a, c) for c in s.obst) * 1000.0


class GPS:
    def __init__(self, sim):
        self.sim = sim

    def enable(self, t):
        pass

    def getValues(self):
        return [self.sim.x, self.sim.y, 0.08]


class Campo:
    def __init__(self, nodo, k):
        self.nodo, self.k = nodo, k

    def _log(self, v):
        print("   [t=%.1f] %s.%s=%s" % (self.nodo.sim.t, self.nodo.name, self.k, v))

    setSFFloat = _log
    setSFColor = _log


class Nodo:
    def __init__(self, sim, name):
        self.sim, self.name = sim, name

    def getField(self, k):
        return Campo(self, k)


class Yo:
    def __init__(self, sim):
        self.sim = sim

    def getOrientation(self):
        c, s = math.cos(self.sim.yaw), math.sin(self.sim.yaw)
        return [c, -s, 0, s, c, 0, 0, 0, 1]


class SupervisorFalso:
    instancia = None
    semana = 12
    max_t = 400.0

    def __init__(self):
        SupervisorFalso.instancia = self
        self.x, self.y, self.yaw, self.t = 0.0, 8.5, 0.0, 0.0
        self.obst = construir_obstaculos(self.semana)
        self.ml, self.mr = Motor(), Motor()
        self.dev = {
            "left wheel motor": self.ml, "right wheel motor": self.mr,
            "ds_left": Sensor(self, .24, .1, .5), "ds_center": Sensor(self, .26, 0, 0),
            "ds_right": Sensor(self, .24, -.1, -.5),
            "ds_left_side": Sensor(self, .1, .15, 1.4), "ds_right_side": Sensor(self, .1, -.15, -1.4),
            "gps": GPS(self),
        }
        self.dt = 0.016
        self.choques = {}
        self.pasos_choque = 0

    def getBasicTimeStep(self): return 16
    def getSelf(self): return Yo(self)
    def getDevice(self, n): return self.dev[n]
    def getFromDef(self, n): return Nodo(self, n) if self.semana >= 8 else None
    def setLabel(self, *a): pass
    def getTime(self): return self.t

    def step(self, ms):
        R, hw = 0.08, 0.19
        vl, vr = self.ml.v * R, self.mr.v * R
        v, w = (vl + vr) / 2, (vr - vl) / (2 * hw)
        self.yaw += w * self.dt
        self.x += v * math.cos(self.yaw) * self.dt
        self.y += v * math.sin(self.yaw) * self.dt
        self.t += self.dt
        for c in self.obst:   # el robot se aproxima con un margen de 0.2 m
            lx, ly = a_local(self.x, self.y, c)
            if abs(lx) < c[3] / 2 + 0.2 and abs(ly) < c[4] / 2 + 0.2:
                self.pasos_choque += 1
                self.choques[c[0]] = self.choques.get(c[0], 0) + 1
        return -1 if self.t > self.max_t else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("controlador", help="carpeta que contiene domiciliario.py")
    ap.add_argument("--semana", type=int, default=12)
    ap.add_argument("--segundos", type=float, default=400.0)
    args = ap.parse_args()

    SupervisorFalso.semana = args.semana
    SupervisorFalso.max_t = args.segundos
    modulo = types.ModuleType("controller")
    modulo.Supervisor = SupervisorFalso
    sys.modules["controller"] = modulo
    sys.path.insert(0, os.path.abspath(args.controlador))
    import domiciliario

    ctrl = None
    if hasattr(domiciliario, "Domiciliario"):
        ctrl = domiciliario.Domiciliario()
        ctrl.run()
    else:
        domiciliario.main()

    s = SupervisorFalso.instancia
    print("-" * 60)
    if ctrl is not None:
        print("estado final:", ctrl.estado, "| entregas:", ctrl.entregas, "/", ctrl.total_entregas)
    print("tiempo simulado: %.1f s | posición final: (%.2f, %.2f)" % (s.t, s.x, s.y))
    print("pasos con choque:", s.pasos_choque, s.choques if s.choques else "")


if __name__ == "__main__":
    main()
