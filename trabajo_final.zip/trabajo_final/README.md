# Trabajo final: Integración final y demostración

**Objetivo:** Cerrar el proyecto: versión final, modo de repetición, resumen, documentación y demo.

## Qué hay de nuevo

- Controlador con `FASE = 12` (versión final; el número de fase se mantiene porque activa las funciones de repetición y resumen)
- Opción `"repetir": true` en `pedidos.json` para repetir la ruta sin parar
- Resumen final en consola: entregas, tiempo, distancia y velocidad media

## Actividades del trabajo final

- [ ] Ejecutar la versión final con 5 clientes (`E, D, C, B, A`) y con `repetir: true`.
- [ ] Revisar que el README principal explica cómo instalar y ejecutar el proyecto.
- [ ] Preparar una demo de 5 minutos: mundo, parque, ruta, evasión y métricas.
- [ ] Escribir 5 mejoras futuras (cámara para leer marcadores, varios robots, tráfico, batería, mapa real).
- [ ] Hacer la autoevaluación con la lista de verificación.

## Cómo ejecutarlo

1. Abre Webots → *File → Open World…* → `worlds/cienaga.wbt` de esta carpeta.
2. Pulsa ▶ (Run). El robot arranca solo.
3. Prueba rápida sin Webots (desde esta carpeta):

```bash
python3 pruebas/simulador_sin_webots.py controllers/domiciliario --semana 12
```

`--semana 12` selecciona la versión final del controlador. Los pedidos se configuran en `controllers/domiciliario/pedidos.json`.

## Entregable

Proyecto final funcionando, demo y documento de mejoras futuras.

## Criterios de evaluación

- Cumple todas las funciones de las semanas anteriores
- La demo es clara y reproducible
- La documentación permite que otra persona lo ejecute

## Lista de verificación final

- [ ] Mundo con calle anillo, casas, parque de 8 entradas con templete, árboles y marcadores
- [ ] Robot con 2 ruedas motrices y 5 sensores
- [ ] Ruta calculada con Dijkstra a partir de `pedidos.json`
- [ ] Evasión de obstáculos y recuperación de atascos
- [ ] Entregas con paquete y marcadores
- [ ] Métricas en CSV y resumen final
- [ ] Pruebas con el simulador

## Siguiente

Proyecto terminado.

---
Carpeta: `trabajo_final`. Proyecto principal: [`../README.md`](../README.md)
